import Foundation

// Implement an Error type. Make sure it has at least two values.
enum pathError: Error {
    case pathFailedToConnect
    case pathFailedToDraw
}

// Implement a function that returns a Result of string or your error type
func winOrLose(value: Int, s: String) -> Result<String, Error> {
    if s == "" {
        return .failure(pathError.pathFailedToDraw)
    }
    if value == 0 {
        return .failure(pathError.pathFailedToConnect)
    }
    
    return .success("You succeeded")
}

// Call your function in a way that will return an error result, and handle that error.
let result = winOrLose(value: 5, s: "")
switch result {
    case .success(let string):
        print("string: \(string)")
    case .failure(let error):
        print(error)
}
// Call your function in a way that will return a success result, and handle the value.
let result2 = winOrLose(value: 5, s: "newesnen")
switch result2 {
    case .success(let string):
        print("string: \(string)")
    case .failure(let error):
        print(error)
}
