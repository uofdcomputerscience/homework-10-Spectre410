import Foundation

// Implement an Error type. Make sure it has at least two values.


// Implement a function that returns a Result of string or your error type


// Call your function in a way that will return an error result, and handle that error.


// Call your function in a way that will return a success result, and handle the value.
